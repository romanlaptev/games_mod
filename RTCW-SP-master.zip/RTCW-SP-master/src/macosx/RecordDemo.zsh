#!/bin/zsh -x



/Local/Public/bungi/BuildOutput/Quake3.app/Contents/MacOS/Quake3 \

  +set sv_pure 0 \

  +set g_syncronousClients 1 \

  +map q3dm6 \

  +record foo





